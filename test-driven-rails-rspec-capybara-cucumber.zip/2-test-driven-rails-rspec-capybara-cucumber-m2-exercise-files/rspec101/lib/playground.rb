class Playground
  def initialize(children)
    @children = children
  end

  def empty?
    @children == 0
  end

  def mood
    'boring'
  end
end
