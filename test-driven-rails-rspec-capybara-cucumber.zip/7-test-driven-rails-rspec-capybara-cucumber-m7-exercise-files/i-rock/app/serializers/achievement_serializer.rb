class AchievementSerializer < ActiveModel::Serializer
  attributes :id, :title
end
