ActiveModel::Serializer.config.adapter = ActiveModel::Serializer::Adapter::JsonApi
